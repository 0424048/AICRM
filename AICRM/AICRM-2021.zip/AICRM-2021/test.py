# -*- coding: utf-8 -*-
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import json
from datetime import timedelta, date
import datetime
import DataCollection
from sqlalchemy import func

# 連結到DB
def connectDB():
    LS = 'mysql+pymysql://root@127.0.0.1/DataFilter?charset=utf8'
    linkObj = create_engine(LS, encoding='utf-8', pool_recycle = True)  # Link to database
    DBsession = sessionmaker(bind=linkObj)  # Database session maker
    session = DBsession()
    return session

def tttt():
    session = connectDB()
    d = DataCollection.MessageFile
    s = session.query(d).all()

    d = DataCollection.SendMessageResult
    for i in  s:
        print(i.FileName)
        store = d(Vendor = i.Vendor, FileName = i.FileName, SendTime=i.CreateTime, MessageStatus_finish = 0, MessageStatus_reservation = 0,MessageStatus_timeout = 0,MessageStatus_error = 0,GA_Click = 0,GA_TransactionTimes=0,GA_Revenue=0,Number=i.Number)
        session.merge(store)
        session.commit()
    session.close()
    return None

def tttt2():
    session = connectDB()
    d = DataCollection.Account
    store = d(Account='Test', Password='000')
    session.merge(store)
    session.commit()
    session.close()
    return None
tttt()
tttt2()